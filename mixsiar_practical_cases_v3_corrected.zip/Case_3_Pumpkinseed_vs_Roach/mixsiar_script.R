# MixSIAR practical script
# Case: Pumpkinseed vs roach
# Question: Does a non-native fish compete with a native fish for similar littoral resources?

# Install packages once if needed:
# install.packages("MixSIAR", dependencies = TRUE)
# install.packages("tidyr")
# install.packages("ggplot2")

library(MixSIAR)
library(tidyr)
library(ggplot2)

# 1. Load the data
mix <- load_mix_data(filename="Consumers.csv",
                     iso_names=c("d13C","d15N"),
                     factors=c("Taxon"),
                     fac_random=c(FALSE),
                     fac_nested=c(FALSE),
                     cont_effects=NULL)

source_data <- load_source_data(filename="Sources.csv",
                           source_factors=NULL,
                           conc_dep=FALSE,
                           data_type="means",
                           mix=mix)

discr <- load_discr_data(filename="TEFs.csv", mix=mix)

# 2. Plot the isospace
plot_data(filename="isospace_plot",
          plot_save_pdf=FALSE,
          plot_save_png=FALSE,
          mix, source_data, discr)

# 3. Write and run the model
model_filename <- "MixSIAR_model.txt"
resid_err <- TRUE
process_err <- TRUE
write_JAGS_model(model_filename, resid_err, process_err, mix, source_data)

# For class, start with a quick run.
# If you have time, change run="short" or use custom MCMC parameters.
jags <- run_model(run="test",
                  mix, source_data, discr, model_filename,
                  alpha.prior=1,
                  resid_err, process_err)

# 4. Save the default MixSIAR outputs
output_options <- list(summary_save = TRUE,
                       summary_name = "summary_statistics",
                       sup_post = FALSE,
                       plot_post_save_pdf = FALSE,
                       plot_post_name = "density_plot",
                       sup_pairs = FALSE,
                       plot_pairs_save_pdf = FALSE,
                       plot_pairs_name = "matrix_plot",
                       sup_xy = FALSE,
                       plot_xy_save_pdf = FALSE,
                       plot_xy_name = "xy_plot",
                       gelman = TRUE,
                       heidel = FALSE,
                       geweke = FALSE,
                       diag_save = TRUE,
                       diag_name = "diagnostics",
                       indiv_effect = FALSE,
                       plot_post_save_png = FALSE,
                       plot_pairs_save_png = FALSE,
                       plot_xy_save_png = FALSE)

output_JAGS(jags, mix, source_data, output_options)

# 5. Extract posterior draws for each taxon
# Posterior draws for Pumpkinseed
post_Pumpkinseed <- as.data.frame(jags$BUGSoutput$sims.list$p.fac1[, which(levels(factor(mix$FAC[[1]])) == "Pumpkinseed"), ])
post_Pumpkinseed$draw <- 1:nrow(post_Pumpkinseed)
post_Pumpkinseed_long <- tidyr::pivot_longer(post_Pumpkinseed,
                                         cols = all_of(source_data$source_names),
                                         names_to = "Source",
                                         values_to = "Contribution")

# Posterior draws for Roach
post_Roach <- as.data.frame(jags$BUGSoutput$sims.list$p.fac1[, which(levels(factor(mix$FAC[[1]])) == "Roach"), ])
post_Roach$draw <- 1:nrow(post_Roach)
post_Roach_long <- tidyr::pivot_longer(post_Roach,
                                         cols = all_of(source_data$source_names),
                                         names_to = "Source",
                                         values_to = "Contribution")

# 6. Plot densities for each taxon
ggplot(post_Pumpkinseed_long, aes(x=Contribution, fill=Source, colour=Source)) +
  geom_density(alpha=0.5) +
  theme_bw() +
  xlim(0,1) +
  ggtitle("Pumpkinseed") +
  theme(plot.title = element_text(hjust = 0.5))

ggplot(post_Roach_long, aes(x=Contribution, fill=Source, colour=Source)) +
  geom_density(alpha=0.5) +
  theme_bw() +
  xlim(0,1) +
  ggtitle("Roach") +
  theme(plot.title = element_text(hjust = 0.5))

# 7. Plot boxplots comparing source contributions within each taxon
ggplot(post_Pumpkinseed_long, aes(x=Source, y=Contribution, fill=Source, colour=Source)) +
  geom_boxplot(alpha=0.6, outlier.shape=NA) +
  theme_bw() +
  ylim(0,1) +
  ggtitle("Pumpkinseed") +
  theme(plot.title = element_text(hjust = 0.5),
        legend.position = "none")

ggplot(post_Roach_long, aes(x=Source, y=Contribution, fill=Source, colour=Source)) +
  geom_boxplot(alpha=0.6, outlier.shape=NA) +
  theme_bw() +
  ylim(0,1) +
  ggtitle("Roach") +
  theme(plot.title = element_text(hjust = 0.5),
        legend.position = "none")

# 8. Compare the two taxa source by source
post <- list(
  "Pumpkinseed" = post_Pumpkinseed,
  "Roach" = post_Roach
)

# Probability that Pumpkinseed has a higher contribution than Roach for each source
mean(post[["Pumpkinseed"]][, "Zooplankton"] > post[["Roach"]][, "Zooplankton"])
mean(post[["Pumpkinseed"]][, "Benthic_insect_larvae"] > post[["Roach"]][, "Benthic_insect_larvae"])
mean(post[["Pumpkinseed"]][, "Macrophyte_invertebrates"] > post[["Roach"]][, "Macrophyte_invertebrates"])
mean(post[["Pumpkinseed"]][, "Plant_material"] > post[["Roach"]][, "Plant_material"])

# 9. Teaching questions
# - Which source is most important for the non-native species?
# - Which source is most important for the native species?
# - Is there strong trophic overlap or clear resource partitioning?
# - Which sources show the greatest uncertainty?
# - Based on these results, would you predict strong competition?
