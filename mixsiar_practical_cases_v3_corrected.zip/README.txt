MixSIAR practical class, 5 fake case studies

This folder contains 5 independent teaching datasets designed for a practical class using MixSIAR.
Each case folder includes:
- Consumers.csv
- Sources.csv
- TEFs.csv
- mixsiar_script.R

All datasets are fake but ecologically plausible.
The consumers file is also compatible with simmr because the isotope columns are d13C and d15N, and the Group column is present.

Suggested classroom workflow
1. Give one case study to each student group.
2. Ask them to run the script.
3. Ask them to interpret isospace plots, posterior densities, and boxplots.
4. Ask them whether the non-native species likely overlaps strongly with the native species.
5. Ask them whether the model output suggests competition, partitioning, or uncertainty.

Case summaries

Case_1_Mink_vs_Otter
Title: American mink vs European otter
Question: Does a non-native mammalian predator overlap trophically with a native top predator after crayfish become available?
Native/non-native comparison: Mink vs Otter
Potential sources: Crayfish, Fish, Amphibians, Waterbirds
Expected pattern:
- The non-native taxon and native taxon differ in source use.
- Some cases show strong overlap, some partial partitioning, and one case (Asian clam vs native mussel) was designed to produce more uncertainty because the sources are isotopically similar.

Case_2_SignalCrayfish_vs_WhiteClawedCrayfish
Title: Signal crayfish vs white-clawed crayfish
Question: Does a non-native crayfish use similar basal and animal resources to a native crayfish?
Native/non-native comparison: Signal crayfish vs White-clawed crayfish
Potential sources: Detritus, Biofilm, Benthic_invertebrates, Macrophytes
Expected pattern:
- The non-native taxon and native taxon differ in source use.
- Some cases show strong overlap, some partial partitioning, and one case (Asian clam vs native mussel) was designed to produce more uncertainty because the sources are isotopically similar.

Case_3_Pumpkinseed_vs_Roach
Title: Pumpkinseed vs roach
Question: Does a non-native fish compete with a native fish for similar littoral resources?
Native/non-native comparison: Pumpkinseed vs Roach
Potential sources: Zooplankton, Benthic_insect_larvae, Macrophyte_invertebrates, Plant_material
Expected pattern:
- The non-native taxon and native taxon differ in source use.
- Some cases show strong overlap, some partial partitioning, and one case (Asian clam vs native mussel) was designed to produce more uncertainty because the sources are isotopically similar.

Case_4_AsianClam_vs_NativeMussel
Title: Asian clam vs native mussel
Question: Do two filter feeders show strong trophic overlap and high model uncertainty because their sources are isotopically similar?
Native/non-native comparison: Asian clam vs Native mussel
Potential sources: SPOM, Phytoplankton, Biofilm, Benthic_OM
Expected pattern:
- The non-native taxon and native taxon differ in source use.
- Some cases show strong overlap, some partial partitioning, and one case (Asian clam vs native mussel) was designed to produce more uncertainty because the sources are isotopically similar.

Case_5_RoundGoby_vs_Bullhead
Title: Round goby vs European bullhead
Question: Does a non-native benthic fish shift toward harder benthic prey compared with a native benthic fish?
Native/non-native comparison: Round goby vs Bullhead
Potential sources: Mussels_snails, Amphipods, Insect_larvae, Fish_eggs
Expected pattern:
- The non-native taxon and native taxon differ in source use.
- Some cases show strong overlap, some partial partitioning, and one case (Asian clam vs native mussel) was designed to produce more uncertainty because the sources are isotopically similar.
