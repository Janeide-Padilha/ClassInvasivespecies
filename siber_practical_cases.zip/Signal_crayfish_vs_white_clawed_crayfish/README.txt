Case: Signal crayfish vs white-clawed crayfish

Question
Do invasive and native crayfish occupy similar trophic space, suggesting strong resource overlap?

Expected pattern
Strong overlap, with signal crayfish showing a slightly broader ellipse.

Files
- SIBER_full.csv: isotopic data in SIBER format
- Key.csv: group labels
- siber_script.R: practical script for this case
