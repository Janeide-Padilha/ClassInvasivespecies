Case: American mink vs European otter

Question
Do mink and otter show isotopic niche overlap, suggesting potential trophic competition, or are they partially segregated?

Expected pattern
Partial overlap, with mink slightly enriched in d15N and more linked to crayfish / bird resources.

Files
- SIBER_full.csv: isotopic data in SIBER format
- Key.csv: group labels
- siber_script.R: practical script for this case
