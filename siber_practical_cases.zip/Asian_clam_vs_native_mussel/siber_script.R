
# SIBER practical script
# Case: Asian clam vs native mussel

library(SIBER)
library(dplyr)
library(ggplot2)

# 1. Load data
fulldata <- read.csv("SIBER_full.csv", header = TRUE)
key <- read.csv("Key.csv", header = TRUE)

# 2. Create SIBER object
siber.obj <- createSiberObject(fulldata)

# 3. Quick base plot
par(mar=c(5.1, 5.1, 4.1, 2.1))
plotSiberObject(
  siber.obj,
  ax.pad = 2,
  hulls = FALSE,
  ellipses = TRUE,
  group.hulls = FALSE,
  bty = "o",
  iso.order = c(1,2),
  xlab = expression({delta}^13*C~'(‰)'),
  ylab = expression({delta}^15*N~'(‰)')
)

# 4. Frequentist ellipse metrics
group.ML <- groupMetricsML(siber.obj)
print(group.ML)

# 5. Bayesian model settings
parms <- list()
parms$n.iter <- 2 * 10^4
parms$n.burnin <- 1 * 10^3
parms$n.thin <- 10
parms$n.chains <- 2

priors <- list()
priors$R <- 1 * diag(2)
priors$k <- 2
priors$tau.mu <- 1.0E-3

# 6. Run Bayesian ellipses
ellipses.post <- siberMVN(siber.obj, parms, priors)
SEA.B <- siberEllipses(ellipses.post)

# 7. Plot Bayesian SEA
siberDensityPlot(
  SEA.B,
  xticklabels = key$Label,
  xlab = "Group",
  ylab = expression("Standard Ellipse Area  " ('‰' ^2)),
  bty = "L",
  las = 1,
  main = "Bayesian estimates of SEA"
)
points(1:ncol(SEA.B), group.ML[3,], col = "red", pch = 16)

# 8. Probability that group 1 has a larger SEA than group 2
Prob.diff.SEA <- sum(SEA.B[,1] > SEA.B[,2]) / NROW(SEA.B[,1])
print(Prob.diff.SEA)

# 9. Maximum likelihood overlap
overlap.ML <- maxLikOverlap("1.1", "1.2", siber.obj, p.interval = NULL, n = 100)
print(overlap.ML)

# Relative overlap
overlap.rel <- overlap.ML[3] / (overlap.ML[1] + overlap.ML[2] - overlap.ML[3])
print(overlap.rel)

# 10. Bayesian overlap
bayes.overlap <- bayesianOverlap("1.1", "1.2", ellipses.post, p.interval = NULL, draws = 100, n = 100)
summary(bayes.overlap[,3])

# 11. Nice ggplot figure
pullEllipseStd <- function(data, x, y) {
  as.data.frame(addEllipse(
    data$ML.mu[[x]][ , , y],
    data$ML.cov[[x]][ , , y],
    m = NULL,
    n = 100,
    p.interval = NULL,
    ci.mean = FALSE,
    do.plot = FALSE
  ))
}

Ellipse_g1 <- pullEllipseStd(data = siber.obj, x = 1, y = 1)
Ellipse_g2 <- pullEllipseStd(data = siber.obj, x = 1, y = 2)

ggplot(fulldata, aes(x = iso1, y = iso2)) +
  geom_point(aes(colour = factor(group), shape = factor(group)), size = 2) +
  geom_path(data = Ellipse_g1, aes(x = V1, y = V2), colour = "#377EB8", size = 1.2) +
  geom_path(data = Ellipse_g2, aes(x = V1, y = V2), colour = "#E41A1C", size = 1.2) +
  scale_colour_manual(
    name = "Group",
    values = c("#377EB8", "#E41A1C"),
    labels = key$Label
  ) +
  scale_shape_manual(
    name = "Group",
    values = c(16, 17),
    labels = key$Label
  ) +
  xlab(expression({delta}^13*C~'(‰)')) +
  ylab(expression({delta}^15*N~'(‰)')) +
  theme_bw()

# 12. Ecological questions for students
cat("\nCase: Asian clam vs native mussel\n")
cat("Question: Do the two filter feeders show substantial isotopic overlap, suggesting similar basal resources?\n")
cat("Expected pattern: High overlap, with only slight separation in d13C.\n")
cat("Interpret:\n")
cat("- Which group has the larger SEA?\n")
cat("- Is overlap high, moderate, or low?\n")
cat("- Does this suggest trophic overlap, segregation, or partial partitioning?\n")
