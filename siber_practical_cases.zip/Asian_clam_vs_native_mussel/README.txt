Case: Asian clam vs native mussel

Question
Do the two filter feeders show substantial isotopic overlap, suggesting similar basal resources?

Expected pattern
High overlap, with only slight separation in d13C.

Files
- SIBER_full.csv: isotopic data in SIBER format
- Key.csv: group labels
- siber_script.R: practical script for this case
