Case: Round goby vs bullhead

Question
Is the invasive round goby trophically distinct from the native bullhead, or do they overlap strongly?

Expected pattern
Moderate overlap, with goby more littoral / benthic and slightly higher in d15N.

Files
- SIBER_full.csv: isotopic data in SIBER format
- Key.csv: group labels
- siber_script.R: practical script for this case
