Case: Pumpkinseed vs roach

Question
Does pumpkinseed occupy a higher trophic position and a different isotopic niche than the native roach?

Expected pattern
Clear segregation, with pumpkinseed higher in d15N and more littoral.

Files
- SIBER_full.csv: isotopic data in SIBER format
- Key.csv: group labels
- siber_script.R: practical script for this case
